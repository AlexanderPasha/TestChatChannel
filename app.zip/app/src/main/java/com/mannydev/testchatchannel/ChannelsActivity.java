package com.mannydev.testchatchannel;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mannydev.testchatchannel.controller.Controller;
import com.mannydev.testchatchannel.controller.SwipeAdder;
import com.mannydev.testchatchannel.model.Channel;
import com.mannydev.testchatchannel.model.LastMessage;
import com.mannydev.testchatchannel.model.Sender;
import com.mannydev.testchatchannel.view.MyChannelAdapter;
import com.mannydev.testchatchannel.view.SpacesItemDecoration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.drakeet.materialdialog.MaterialDialog;

/**
 * Created by manny on 19.10.17.
 */

public class ChannelsActivity extends AppCompatActivity {

    @BindView(R.id.txtChat)
    TextView txtChat;
    @BindView(R.id.txtLiveChat)
    TextView txtLiveChat;
    MyChannelAdapter myChannelAdapter;
    static List<Channel> list;
    MaterialDialog materialDialog;
    @BindView(R.id.txtTitle)
    TextView txtTitle;
    @BindView(R.id.btnNewMessage)
    Button btnNewMessage;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.btnAllUnreadedMessages)
    Button btnAllUnreadedMessages;
    @BindView(R.id.btnLiveChats)
    Button btnLiveChats;
    @BindView(R.id.llChat)
    LinearLayout llChat;
    @BindView(R.id.llLiveChat)
    LinearLayout llLiveChat;
    @BindView(R.id.btnHome)
    Button btnHome;
    @BindView(R.id.rvChannels)
    RecyclerView rvChannels;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        ButterKnife.bind(this);

        Controller controller = new Controller();
        final List<Channel>emptyList = new ArrayList<>();
        list = controller.getList();
        controller.addDividers(list);
        Collections.sort(list,new SortedByMessages());
        Collections.reverse(list);

        btnAllUnreadedMessages.setText(String.valueOf(controller.getUnreadedMessages()));

        //SpacesItemDecoration decoration = new SpacesItemDecoration(20);
        //rvChannels.addItemDecoration(decoration);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        rvChannels.setLayoutManager(mLayoutManager);
        myChannelAdapter = new MyChannelAdapter(list);
        new SwipeAdder(this).addSwipes(rvChannels, myChannelAdapter, list);
        rvChannels.setAdapter(myChannelAdapter);



        //Заглушка на New Message
        materialDialog = addFakeDialog();

    }

    private void getChannelsList(List<Channel> list, RecyclerView rv) {
        MyChannelAdapter myChannelAdapter = new MyChannelAdapter(list);
        rv.setAdapter(myChannelAdapter);
    }

    //Реализация кнопки "Домой"
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @OnClick({R.id.llChat, R.id.llLiveChat, R.id.btnNewMessage, R.id.btnHome})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.llChat:
                setEnabledLayout(llChat, llLiveChat);

                break;
            case R.id.llLiveChat:
                setEnabledLayout(llLiveChat, llChat);
                //выводим что-то...
                break;
            case R.id.btnNewMessage:
                materialDialog.show();
                break;
            case R.id.btnHome:
                finish();
                break;
        }
    }

    private void setEnabledLayout(LinearLayout firstLayout, LinearLayout secondLayout) {
        firstLayout.setBackgroundResource(R.drawable.enabled_chat_style);
        secondLayout.setBackgroundColor(Color.TRANSPARENT);
        switch (firstLayout.getId()) {
            case R.id.llChat:
                txtChat.setTextColor(getResources().getColor(R.color.charcoal_grey));
                txtLiveChat.setTextColor(getResources().getColor(R.color.another2));
                getChannelsList(list, rvChannels);
                break;
            case R.id.llLiveChat:
                txtLiveChat.setTextColor(getResources().getColor(R.color.charcoal_grey));
                txtChat.setTextColor(getResources().getColor(R.color.another2));
                getChannelsList(Collections.<Channel>emptyList(), rvChannels);
                break;
        }

    }

    //Заглушка для кнопки "Новое сообщение"
    private MaterialDialog addFakeDialog() {
        final MaterialDialog materialDialog = new MaterialDialog(ChannelsActivity.this);
        materialDialog.setTitle("Заглушка");
        materialDialog.setMessage("А могла быть форма для создания нового сообщения... ))");
        materialDialog.setPositiveButton("Принял!", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
            }
        });
        return materialDialog;
    }



}

class CompChannels implements Comparator<Channel> {
    @Override
    public int compare(Channel channel, Channel t1) {
        int flag = t1.getUnreadMessagesCount()-channel.getUnreadMessagesCount();
        if(flag==0) flag = t1.getLastMessage().getSender().getId()-channel.getLastMessage().getSender().getId();
        return flag;
    }
}

class SortedByMessages implements Comparator<Channel> {

    public int compare(Channel obj1, Channel obj2) {

        double un1 = obj1.getUnreadMessagesCount();
        double un2 = obj2.getUnreadMessagesCount();
        int id = obj1.getLastMessage().getSender().getId();

        if(un1 > un2||un1==un2&&id==0) {
            return 1;
        }
        else if(un1 < un2) {
            return -1;
        }
        else {
            return 0;
        }
    }
}

