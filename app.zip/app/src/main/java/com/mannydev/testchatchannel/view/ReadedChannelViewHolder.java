package com.mannydev.testchatchannel.view;

import android.content.Intent;
import android.view.View;

import com.mannydev.testchatchannel.SenderActivity;
import com.mannydev.testchatchannel.controller.Controller;
import com.mannydev.testchatchannel.model.Channel;
import com.squareup.picasso.Picasso;

import jp.wasabeef.picasso.transformations.CropCircleTransformation;

/**
 * Created by manny on 21.10.17.
 */

public class ReadedChannelViewHolder extends ChannelViewHolder {
    Controller cntr;

    public ReadedChannelViewHolder(View itemView) {
        super(itemView);
        cntr = new Controller();
    }

    @Override
    public void bindChannelHolder(Channel ch) {
        txtSender.setText(ch.getLastMessage()
                .getSender().getFirstName()
                +" "+ch.getLastMessage().getSender().getLastName());
        txtLastMessage.setText(cntr.cutLongMessageText(ch.getLastMessage().getText()));
        txtCreateDate.setText(cntr.parseDate(ch.getLastMessage().getCreateDate()));
        Picasso.with(itemView.getContext().getApplicationContext())
                .load(ch.getLastMessage().getSender().getPhoto()+"+"+ch.getLastMessage()
                .getSender().getId()).transform(new CropCircleTransformation())
                .fit().centerCrop().into(ivAvatar);
        ivAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(itemView.getContext()
                        .getApplicationContext(), SenderActivity.class);
                intent.putExtra("sender",txtSender.getText());
                itemView.getContext().startActivity(intent);
            }
        });
    }


}
