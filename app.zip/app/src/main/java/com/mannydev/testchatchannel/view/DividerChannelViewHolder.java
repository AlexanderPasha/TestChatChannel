package com.mannydev.testchatchannel.view;

import android.view.View;

import com.mannydev.testchatchannel.model.Channel;

/**
 * Created by manny on 21.10.17.
 */

public class DividerChannelViewHolder extends ChannelViewHolder {

    public DividerChannelViewHolder(View itemView) {
        super(itemView);
    }

    @Override
    public void bindChannelHolder(Channel ch) {

    }
}
