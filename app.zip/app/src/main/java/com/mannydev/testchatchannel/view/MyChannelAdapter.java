package com.mannydev.testchatchannel.view;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.mannydev.testchatchannel.R;
import com.mannydev.testchatchannel.model.Channel;

import java.util.List;

/**
 * Created by manny on 21.10.17.
 */

public class MyChannelAdapter extends RecyclerView.Adapter<ChannelViewHolder> {
    private  static final int UNREAD = 1;
    private  static final int READ = 0;
    private  static final int DIVIDER = -1;
    private List<Channel> list;

    public MyChannelAdapter(List<Channel> list) {
        this.list = list;
    }

    @Override
    public ChannelViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(viewType==UNREAD) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.channels_view_unreaded, parent, false);
            return new UnreadedChannelViewHolder(v);
        }else if(viewType==DIVIDER) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.zaglushka, parent, false);
            return new DividerChannelViewHolder(v);
        }else {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.channels_view_readed, parent, false);
            return new ReadedChannelViewHolder(v);
        }

    }

    @Override
    public void onBindViewHolder(ChannelViewHolder holder, int position) {
        holder.bindChannelHolder(list.get(position));
    }


    @Override
    public int getItemViewType(int position) {
        Channel ch = list.get(position);
        if(ch.getUnreadMessagesCount()>0&&ch.getUnreadMessagesCount()<1000){
            return UNREAD;
        }else if(ch.getLastMessage().getSender().getId()==0||ch.getUnreadMessagesCount()==-1
                ||ch.getUnreadMessagesCount()==1000){
            return DIVIDER;
        }else if(ch.getUnreadMessagesCount()==0) {
            return READ;
        }return READ;

    }

    @Override
    public int getItemCount() {
        if (list == null)
            return 0;
        return list.size();
    }
}
