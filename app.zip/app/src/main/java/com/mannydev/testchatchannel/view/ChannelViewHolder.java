package com.mannydev.testchatchannel.view;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.mannydev.testchatchannel.R;
import com.mannydev.testchatchannel.model.Channel;

/**
 * Created by manny on 21.10.17.
 */

abstract class ChannelViewHolder extends RecyclerView.ViewHolder {
    ImageView ivAvatar;
    TextView txtSender;
    TextView txtLastMessage;
    TextView txtCreateDate;


    public ChannelViewHolder(View itemView) {
        super(itemView);
        ivAvatar = (ImageView) itemView.findViewById(R.id.ivAvatar);
        txtSender = (TextView) itemView.findViewById(R.id.txtSender);
        txtLastMessage = (TextView) itemView.findViewById(R.id.txtLastMessage);
        txtCreateDate = (TextView)itemView.findViewById(R.id.txtCreateDate);

    }

    public abstract void bindChannelHolder(Channel ch);

}
